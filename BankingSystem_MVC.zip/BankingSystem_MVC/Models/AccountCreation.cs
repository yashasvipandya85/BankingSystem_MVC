﻿using System.ComponentModel.DataAnnotations;

namespace BankingSystem_MVC.Models
{
    public class AccountCreation
    {
        [Required]
        [StringLength(100)]
        public string HolderName { get; set; }

        public string AccountNumber { get; set; }

        [Required]
        public int CusId { get; set; }

        [Required]
        [StringLength(20)]
        public string AccountType { get; set; }

        [Required]
        public string IFSC { get; set; }

        [Required]
        [StringLength(50)]
        public string BranchName { get; set; }

        [Phone]
        public string BranchPhoneNo { get; set; }

        [EmailAddress]
        public string BranchEmailId { get; set; }

        public string BranchAddress { get; set; }
    }
}
