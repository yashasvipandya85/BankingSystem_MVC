﻿namespace BankingSystem_MVC.Models
{
    public class AccountStatementViewModel
    {
        public int CusId { get; set; }
        public string HolderName { get; set; }
        public string BranchName { get; set; }
        public string AccountNumber { get; set; }
        public decimal Balance { get; set; }
        public List<TransactionViewModel> Transactions { get; set; }
    }
}
