﻿using Microsoft.AspNetCore.Mvc;
using BankingSystem_MVC.Models;
using BankingSystem_MVC.Services;
using Newtonsoft.Json;
using System.Net.Http;
using System.Text;
using System.Net;
namespace BankingSystem_MVC.Controllers
{
    public class CustomerController : Controller
    {
        private readonly ICustomerService _customerService;
        
        public CustomerController(ICustomerService customerService)
        {
            _customerService = customerService;
        }
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(Customer customer)
        {
            try
            {
                
                int userId = GetUserIdFromLogin(); 
                var success = await _customerService.CreateCustomerAsync(customer, userId);

                if (success)
                {
                    ViewBag.Message = "Customer created successfully.";
                }
                else
                {
                    ViewBag.Message = "Failed to create the customer. Please try again.";
                }

                return View();
            }
            catch (Exception ex)
            {
                ViewBag.Message = $"An error occurred while creating the customer: {ex.Message}";
                return View();
            }
        }

        private int GetUserIdFromLogin()
        {
            return 1; 
        }

        [HttpGet]
        public async Task<IActionResult> ViewProfile(int customerId)
        {
            try
            {
                // Fetch customer details
                var customer = await _customerService.GetCustomerProfileAsync(customerId);

                if (customer == null)
                {
                    ViewBag.Message = "Customer not found.";
                    return View("Error");
                }

                return View(customer);
            }
            catch (Exception ex)
            {
                ViewBag.Message = $"An error occurred: {ex.Message}";
                return View("Error"); 
            }
        }
        [HttpGet]
        public async Task<IActionResult> UpdateCustomer(int cusId)
        {
            Console.WriteLine($"Entering UpdateCustomer action for CusId: {cusId}");

            try
            {
                var customer = await _customerService.GetCustomerByIdAsync(cusId); 
                if (customer == null)
                {
                    Console.WriteLine($"Customer with ID {cusId} not found.");
                    TempData["ErrorMessage"] = "Customer not found.";
                    return RedirectToAction("Error");
                }

                return View(customer); // Pass customer to the view for editing
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception while fetching customer details: {ex.Message}");
                TempData["ErrorMessage"] = "An error occurred while fetching customer details.";
                return RedirectToAction("Error");
            }
        }
        [HttpPost]
        public async Task<IActionResult> SaveCustomerChanges(Customer customer)
        {
            Console.WriteLine($"Entering SaveCustomerChanges for CusId: {customer.CusId}");

            try
            { 
                var success = await _customerService.UpdateCustomerAsync(customer);
                if (!success)
                {
                    Console.WriteLine("[ERROR] Failed to update customer details.");
                    TempData["ErrorMessage"] = "Failed to update customer details.";
                    return RedirectToAction("Error");
                }

                Console.WriteLine("[INFO] Customer updated successfully.");
                TempData["SuccessMessage"] = "Customer details updated successfully.";
                return RedirectToAction("GetAllCustomers", "Manager"); // Redirect back to customer list
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception while updating customer details: {ex.Message}");
                TempData["ErrorMessage"] = "An error occurred while updating customer details.";
                return RedirectToAction("Error");
            }
        }

    }
}
