﻿using BankingSystem_MVC.Models;
using BankingSystem_MVC.Services;
using Newtonsoft.Json;
using System.Net.Http.Headers;

namespace BankingSystem_MVC.Repository
{
    public class AccountRepository : IAccountService
    {
        private readonly HttpClient _httpClient;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public AccountRepository(HttpClient httpClient, IHttpContextAccessor httpContextAccessor)
        {
            _httpClient = httpClient;
            _httpContextAccessor = httpContextAccessor;
        }

       
        public async Task<Account> CreateAccountAsync(Account model, int userId)
        {
            try
            {
                // Validate UserId
                if (userId <= 0)
                {
                    Console.WriteLine("Error: Invalid userId provided. Ensure UserId is properly set.");
                    throw new Exception("UserId is invalid.");
                }
                Console.WriteLine($"UserId validated successfully: {userId}");

                // Validate the payload (Account model)
                if (model == null)
                {
                    Console.WriteLine("Error: Payload (Account model) is null.");
                    throw new Exception("Payload is null. Ensure Account model is initialized properly.");
                }

                // Log AccountNumber before further validation
                if (string.IsNullOrEmpty(model.AccountNumber))
                {
                    Console.WriteLine("AccountNumber is null or empty in the incoming payload.");
                }
                else
                {
                    Console.WriteLine($"AccountNumber received in payload: {model.AccountNumber}");
                }

                // Check required fields
                if (string.IsNullOrEmpty(model.HolderName) || model.CusId <= 0 || string.IsNullOrEmpty(model.AccountType))
                {
                    Console.WriteLine("Error: Required fields in the Account model are missing or invalid.");
                    Console.WriteLine($"HolderName: {model.HolderName}, CusId: {model.CusId}, AccountType: {model.AccountType}");
                    throw new Exception("Invalid payload. Ensure all required fields are populated.");
                }

                // Log the entire payload for debugging
                Console.WriteLine($"Payload validated successfully: {Newtonsoft.Json.JsonConvert.SerializeObject(model)}");

                // Construct URL
                var url = $"https://localhost:7277/api/Account/create?userId={userId}";
                Console.WriteLine($"Request URL constructed successfully: {url}");

                // Send POST request
                Console.WriteLine("Sending HTTP POST request...");
                var response = await _httpClient.PostAsJsonAsync(url, model);
                Console.WriteLine($"HTTP POST request sent to URL: {url}");

                // Handle response
                if (response.IsSuccessStatusCode)
                {
                    Console.WriteLine("HTTP response status: Success");

                    // Log and deserialize the response
                    var account = await response.Content.ReadFromJsonAsync<Account>();
                    Console.WriteLine($"Response Account Details: {Newtonsoft.Json.JsonConvert.SerializeObject(account)}");

                    // Log AccountNumber in the response
                    if (!string.IsNullOrEmpty(account.AccountNumber))
                    {
                        Console.WriteLine($"AccountNumber generated successfully: {account.AccountNumber}");
                    }
                    else
                    {
                        Console.WriteLine("Warning: AccountNumber is null in the response.");
                    }

                    return account;
                }

                // Log specific error cases based on response status
                Console.WriteLine($"HTTP response status: {response.StatusCode}");
                if (response.StatusCode == System.Net.HttpStatusCode.BadRequest)
                {
                    Console.WriteLine("Error: Bad Request. Verify payload and query string parameters.");
                }
                else if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                {
                    Console.WriteLine("Error: Unauthorized. Ensure authentication credentials are included.");
                }
                else if (response.StatusCode == System.Net.HttpStatusCode.Forbidden)
                {
                    Console.WriteLine("Error: Forbidden. Check API access permissions.");
                }
                else if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
                {
                    Console.WriteLine("Error: Not Found. Verify the API endpoint URL.");
                }
                else
                {
                    Console.WriteLine($"Unexpected error occurred. HTTP status code: {response.StatusCode}");
                }

                // Throw exception for unsuccessful responses
                throw new Exception($"Account creation failed. Status code: {response.StatusCode}");
            }
            catch (Exception ex)
            {
                // Log any exceptions that occur during execution
                Console.WriteLine($"Exception occurred: {ex.Message}");
                Console.WriteLine($"Stack Trace: {ex.StackTrace}");
                throw;
            }
        }

        public async Task<bool> DepositAsync(TransactionViewModel model)
        {
            try
            {
                var response = await _httpClient.PostAsJsonAsync("https://localhost:7277/api/Account/deposit", model);

                return response.IsSuccessStatusCode;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in DepositAsync: {ex.Message}");
                return false;
            }
        }

        public async Task<(bool isSuccess, string message)> WithdrawAsync(TransactionViewModel model)
        {
            try
            {
                var response = await _httpClient.PostAsJsonAsync("https://localhost:7277/api/Account/withdraw", model);

                if (response.IsSuccessStatusCode)
                {
                    var responseData = await response.Content.ReadAsStringAsync();
                    var result = JsonConvert.DeserializeObject<dynamic>(responseData);
                    return (true, (string)result.message);
                }
                else
                {
                    var errorData = await response.Content.ReadAsStringAsync();
                    var errorMessage = JsonConvert.DeserializeObject<dynamic>(errorData)?.message;
                    return (false, errorMessage ?? "Withdrawal failed.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in WithdrawAsync: {ex.Message}");
                return (false, "An error occurred during the withdrawal process.");
            }
        }

        public async Task<AccountStatementViewModel> GetAccountStatementAsync(int userId)
        {
            try
            {
                // Log the start of the request
                Console.WriteLine($"[INFO] Starting GetAccountStatementAsync for UserId: {userId} at {DateTime.UtcNow}");

                // Construct the API request URL
                var requestUrl = $"https://localhost:7277/api/Account/view-account-statement?userId={userId}";
                Console.WriteLine($"[INFO] Sending GET request to: {requestUrl}");

                // Send the HTTP GET request
                var response = await _httpClient.GetAsync(requestUrl);

                // Log response status
                Console.WriteLine($"[INFO] Received HTTP response with status code: {response.StatusCode}");

                if (response.IsSuccessStatusCode)
                {
                    // Log that the response was successful
                    Console.WriteLine($"[INFO] HTTP request successful for UserId: {userId}. Status Code: {response.StatusCode}");

                    // Read and deserialize the response content
                    var responseData = await response.Content.ReadAsStringAsync();
                    Console.WriteLine($"[INFO] Response content: {responseData}");

                    var accountStatement = JsonConvert.DeserializeObject<AccountStatementViewModel>(responseData);
                    Console.WriteLine($"[INFO] Successfully deserialized account statement for UserId: {userId}");

                    // Log the completion of the method
                    Console.WriteLine($"[INFO] Completed GetAccountStatementAsync for UserId: {userId} at {DateTime.UtcNow}");

                    return accountStatement;
                }
                else
                {
                    // Log failure details for non-success status codes
                    Console.WriteLine($"[WARNING] HTTP request failed for UserId: {userId}. Status Code: {response.StatusCode}");
                    var errorContent = await response.Content.ReadAsStringAsync();
                    Console.WriteLine($"[WARNING] Error content: {errorContent}");
                    return null;
                }
            }
            catch (Exception ex)
            {
                // Log the exception with full details
                Console.WriteLine($"[ERROR] Exception occurred in GetAccountStatementAsync for UserId: {userId} at {DateTime.UtcNow}");
                Console.WriteLine($"[ERROR] Exception Message: {ex.Message}");
                Console.WriteLine($"[ERROR] Stack Trace: {ex.StackTrace}");
                return null;
            }
        }

        public async Task<AccountSummaryViewModel> GetAccountSummaryAsync(int userId)
        {
            try
            {
                // Pass userId in the query string
                var response = await _httpClient.GetAsync($"https://localhost:7277/api/Account/account-summary?userId={userId}");

                // Log the response status
                Console.WriteLine($"[INFO] Received response for UserId {userId} with status code: {response.StatusCode}");

                if (response.IsSuccessStatusCode)
                {
                    var responseData = await response.Content.ReadAsStringAsync();
                    Console.WriteLine($"[INFO] Response content for UserId {userId}: {responseData}");

                    return JsonConvert.DeserializeObject<AccountSummaryViewModel>(responseData);
                }
                else
                {
                    Console.WriteLine($"[WARNING] Failed to fetch account summary for UserId {userId}. Status code: {response.StatusCode}");
                    return null;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[ERROR] Exception occurred while fetching account summary for UserId {userId}. Message: {ex.Message}");
                return null;
            }
        }
        public async Task<ShowBalanceViewModel> GetBalanceAsync()
        {
            // Retrieve the JWT token from the session
            var token = _httpContextAccessor.HttpContext.Session.GetString("JwtToken");
            if (string.IsNullOrEmpty(token))
            {
                throw new UnauthorizedAccessException("User is not logged in.");
            }

            // Include the token in the Authorization header
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);

            // Send the GET request to the backend API
            var response = await _httpClient.GetAsync("https://localhost:7277/api/Account/show-balance");

            if (response.IsSuccessStatusCode)
            {
                var responseData = await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<ShowBalanceViewModel>(responseData);
            }

            if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
            {
                throw new UnauthorizedAccessException("Token is invalid or expired.");
            }

            return null;
        }
    }
}
