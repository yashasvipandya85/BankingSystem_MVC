﻿using BankingSystem_MVC.Models;

namespace BankingSystem_MVC.Services
{
    public interface ICustomerService
    {
        Task<bool> CreateCustomerAsync(Customer customer, int userId);
        Task<Customer> GetCustomerProfileAsync(int customerId);
        Task<bool> UpdateCustomerAsync(Customer customer);
        Task<Customer> GetCustomerByIdAsync(int cusId);
    }
}
