﻿using System.ComponentModel.DataAnnotations;

namespace BankingSystem_MVC.Models
{
    public class Customer
    {
        public int CusId { get; set; }

        [Required(ErrorMessage = "Full Name is required")]
        public string FullName { get; set; }

        [Required(ErrorMessage = "Mobile Number is required")]
        [Phone(ErrorMessage = "Invalid Mobile Number format")]

        public string MobileNo { get; set; }

        [Required(ErrorMessage = "Email Address is required")]
        [EmailAddress(ErrorMessage = "Invalid Email Address format")]
        public string EmailId { get; set; }

        [Required(ErrorMessage = "Aadhar Number is required")]
        public string AadhaarNo { get; set; }

        [Required(ErrorMessage = "Pan card Number is required")]
        public string PanCardNo { get; set; }

        [Required(ErrorMessage = "Date of Birth is required")]
        public DateTime DOB { get; set; }

        public string OccupationType { get; set; }
        public string? Status { get; set; }
        public string Address { get; set; }
    }
}
