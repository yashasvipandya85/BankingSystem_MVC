﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace BankingSystem_MVC.Models
{
    public class UserAccountStatus
    {
        [Key]
        public int UserAccountStatusId { get; set; }

        [Required]
        public int UserId { get; set; }
        public int FailedLoginAttempts { get; set; }
        public bool IsLocked { get; set; }

        [ForeignKey("UserId")]
        public User User { get; set; }
    }
}
