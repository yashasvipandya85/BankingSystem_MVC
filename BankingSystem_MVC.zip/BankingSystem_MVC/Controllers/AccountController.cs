﻿using Microsoft.IdentityModel.Tokens;
using Microsoft.AspNetCore.Mvc;
using BankingSystem_MVC.Services;
using BankingSystem_MVC.Models;
namespace BankingSystem_MVC.Controllers
{
    public class AccountController : Controller
    {
        private readonly IAccountService _accountService;
        public AccountController(IAccountService accountService)
        {
            _accountService = accountService;
        }

        public IActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public IActionResult Create()
        {
            return View(new AccountCreation());
        }

        [HttpPost]
        public async Task<IActionResult> Create(AccountCreation model)
        {
            // Validate the input model
            if (!ModelState.IsValid)
            {
                Console.WriteLine("Error: Model validation failed. Missing or invalid fields in the AccountCreation model.");

                // Log details of ModelState errors
                foreach (var state in ModelState)
                {
                    if (state.Value.Errors.Any())
                    {
                        Console.WriteLine($"ModelState Error: Field {state.Key}, Errors: {string.Join(", ", state.Value.Errors.Select(e => e.ErrorMessage))}");
                    }
                }

                return View(model); // Redisplay the form with validation errors
            }

            try
            {
                // Retrieve UserId from session
                var userIdString = HttpContext.Session.GetString("UserId");
                if (string.IsNullOrEmpty(userIdString) || !int.TryParse(userIdString, out int userId))
                {
                    Console.WriteLine("Error: UserId not found or invalid in session.");
                    ModelState.AddModelError("", "You are not logged in. Please log in to create an account.");
                    return View(model);
                }
                Console.WriteLine($"UserId validated successfully: {userId}");

                // Log all fields from the AccountCreation model
                Console.WriteLine($"Received AccountCreation model: {Newtonsoft.Json.JsonConvert.SerializeObject(model)}");

                // Check for AccountNumber field
                if (string.IsNullOrEmpty(model.AccountNumber))
                {
                    Console.WriteLine("AccountNumber is null or empty in the received model. It will not be sent to the backend.");
                }
                else
                {
                    Console.WriteLine($"AccountNumber received in model: {model.AccountNumber}");
                }

                // Map the AccountCreation (view model) to Account (backend model)
                var newAccount = new Account
                {
                    HolderName = model.HolderName,
                    AccountNumber = model.AccountNumber,
                    CusId = model.CusId,
                    AccountType = model.AccountType,
                    IFSC = model.IFSC,
                    BranchName = model.BranchName,
                    BranchPhoneNo = model.BranchPhoneNo,
                    BranchEmailId = model.BranchEmailId,
                    BranchAddress = model.BranchAddress,
                    Balance = 1000m, // Default balance
                    AccCreationDate = DateTime.UtcNow, // Current date
                    UserId = userId // Dynamically assigned UserId from session
                };

                // Log mapped Account object
                Console.WriteLine($"Mapped Account object (backend model): {Newtonsoft.Json.JsonConvert.SerializeObject(newAccount)}");

                // Call the service with both the Account object and UserId
                Console.WriteLine("Calling CreateAccountAsync service...");
                var result = await _accountService.CreateAccountAsync(newAccount, userId);

                // Success Log
                Console.WriteLine("Service call completed successfully.");
                Console.WriteLine($"Response from service: {Newtonsoft.Json.JsonConvert.SerializeObject(result)}");

                // Check the AccountNumber in the response
                if (!string.IsNullOrEmpty(result.AccountNumber))
                {
                    Console.WriteLine($"Account successfully created! Account Number: {result.AccountNumber}");
                }
                else
                {
                    Console.WriteLine("Warning: AccountNumber is null in the backend response.");
                }

                TempData["SuccessMessage"] = $"Account created successfully! Account Number: {result.AccountNumber}";
                return RedirectToAction("Create"); // Redirect to clear the form and display success
            }
            catch (UnauthorizedAccessException uaEx)
            {
                // Log unauthorized errors
                Console.WriteLine($"Error: Unauthorized access. Details: {uaEx.Message}");
                ModelState.AddModelError("", "Unauthorized access. Please log in to create an account.");
                return View(model);
            }
            catch (Exception ex)
            {
                // Log all other exceptions
                Console.WriteLine($"An unexpected error occurred: {ex.Message}");
                Console.WriteLine($"Stack Trace: {ex.StackTrace}");
                ModelState.AddModelError("", $"An error occurred while creating the account: {ex.Message}");
                return View(model);
            }
        }

        [HttpGet]
        public IActionResult Deposit()
        {
            return View(new TransactionViewModel());
        }

        [HttpPost]
        public async Task<IActionResult> Deposit(TransactionViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var success = await _accountService.DepositAsync(model);
            if (success)
            {
                TempData["SuccessMessage"] = "Deposit completed successfully.";
                return RedirectToAction("Index", "Account");
            }

            TempData["ErrorMessage"] = "Deposit failed. Please try again.";
            return View(model);
        }

        [HttpGet]
        public IActionResult Withdraw()
        {
            return View(new TransactionViewModel());
        }

        [HttpPost]
        public async Task<IActionResult> Withdraw(TransactionViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var (isSuccess, message) = await _accountService.WithdrawAsync(model);

            if (isSuccess)
            {
                TempData["SuccessMessage"] = "Withdrawal successful.";
                return RedirectToAction("Index", "Account");
            }

            TempData["ErrorMessage"] = message;
            return View(model);
        }

        
        public async Task<IActionResult> ViewAccountStatement()
        {
            // Retrieve UserId from session
            var userIdString = HttpContext.Session.GetString("UserId");
            if (string.IsNullOrEmpty(userIdString) || !int.TryParse(userIdString, out int userId))
            {
                TempData["ErrorMessage"] = "Your session has expired or you are not logged in. Please log in again.";
                return RedirectToAction("Login", "User");
            }

            // Fetch the account statement using the service
            var accountStatement = await _accountService.GetAccountStatementAsync(userId);

            if (accountStatement == null)
            {
                TempData["ErrorMessage"] = "Failed to retrieve account statement. Please try again later.";
                return RedirectToAction("Dashboard", "Customer");
            }

            return View(accountStatement);
        }

        [HttpGet]
        public async Task<IActionResult> GetAccountSummary()
        {
            // Log entry point
            Console.WriteLine("Entering GetAccountSummary method.");

            // Retrieve UserId from session
            var userIdString = HttpContext.Session.GetString("UserId");
            if (string.IsNullOrEmpty(userIdString))
            {
                Console.WriteLine("UserId not found in session for retrieving account summary.");
                TempData["ErrorMessage"] = "Your session has expired or you are not logged in. Please log in again.";
                return RedirectToAction("Login", "User");
            }

            // Parse UserId from session
            if (!int.TryParse(userIdString, out int userId))
            {
                Console.WriteLine("Failed to parse UserId from session.");
                TempData["ErrorMessage"] = "Invalid session data. Please log in again.";
                return RedirectToAction("Login", "User");
            }

            // Log UserId retrieval
            Console.WriteLine($"Fetching account summary for UserId: {userId}");

            try
            {
                // Fetch the account summary using the service
                var accountSummary = await _accountService.GetAccountSummaryAsync(userId);

                if (accountSummary == null)
                {
                    Console.WriteLine($"Account not found for UserId: {userId}");
                    TempData["ErrorMessage"] = "Account not found. Please try again later.";
                    return RedirectToAction("Dashboard", "Customer");
                }

                // Log successful retrieval
               Console.WriteLine($"Account summary retrieved successfully for UserId: {userId}");
                return View(accountSummary);
            }
            catch (Exception ex)
            {
                // Handle unexpected errors
                Console.WriteLine($"An error occurred while fetching account summary for UserId: {userId}");
                TempData["ErrorMessage"] = "An unexpected error occurred. Please try again.";
                return RedirectToAction("Dashboard", "Customer");
            }
        }

        [HttpGet]
        public async Task<IActionResult> ShowBalance()
        {
            try
            {
                // Call the repository to get the balance
                var balance = await _accountService.GetBalanceAsync();

                // Pass the data to the view
                return View(balance);
            }
            catch (UnauthorizedAccessException ex)
            {
                TempData["ErrorMessage"] = "Your session has expired. Please log in again.";
                return RedirectToAction("Login", "User");
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = "An unexpected error occurred. Please try again.";
                Console.WriteLine($"[ERROR] {ex.Message}");
                return RedirectToAction("Dashboard", "Customer");
            }
        }
    }
}

