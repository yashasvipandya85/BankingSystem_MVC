﻿using BankingSystem_MVC.Models;
using BankingSystem_MVC.Services;
using Newtonsoft.Json;
using System.Text.Json;

namespace BankingSystem_MVC.Repository
{
    public class ManagerRepository : IManagerService
    {
        private readonly HttpClient _httpClient;
         public ManagerRepository(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }
       
        public async Task<ManagerInfo> CreateManagerAsync(ManagerInfo managerInfo, int userId)
        {
            if (managerInfo == null)
            {
                throw new ArgumentNullException(nameof(managerInfo), "ManagerInfo cannot be null.");
            }

            // Construct the URL with userId in the query string
            var url = $"https://localhost:7277/api/Manager/create?userId={userId}";
            Console.WriteLine($"Constructed URL: {url}");
            Console.WriteLine($"Payload for POST request: {Newtonsoft.Json.JsonConvert.SerializeObject(managerInfo)}");

            try
            {
                // Send POST request to backend
                Console.WriteLine("Sending manager creation data to the backend...");
                var response = await _httpClient.PostAsJsonAsync(url, managerInfo);

                Console.WriteLine($"HTTP Response Status Code: {response.StatusCode}");
                if (response.IsSuccessStatusCode)
                {
                    Console.WriteLine("Manager creation succeeded. Reading response data...");
                    return await response.Content.ReadFromJsonAsync<ManagerInfo>();
                }

                // Log error response
                var errorContent = await response.Content.ReadAsStringAsync();
                Console.WriteLine($"Manager creation failed. Response Content: {errorContent}");
                throw new Exception($"Manager creation failed. Status Code: {response.StatusCode}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An unexpected exception occurred: {ex.Message}");
                Console.WriteLine($"Stack Trace: {ex.StackTrace}");
                throw;
            }
        }
        public async Task<IEnumerable<ManagerInfo>> GetAllManagersAsync(int userId)
        {
            if (userId <= 0)
            {
                throw new ArgumentException("Invalid UserId", nameof(userId));
            }

            // Construct the API URL with UserId in the query string
            var url = $"https://localhost:7277/api/Manager/all-managers?userId={userId}";
            Console.WriteLine($"Constructed URL: {url}");

            try
            {
                // Send GET request to backend
                Console.WriteLine("Sending request to fetch all managers...");
                var response = await _httpClient.GetAsync(url);

                Console.WriteLine($"HTTP Response Status Code: {response.StatusCode}");
                if (response.IsSuccessStatusCode)
                {
                    Console.WriteLine("Successfully fetched managers from backend.");
                    return await response.Content.ReadFromJsonAsync<IEnumerable<ManagerInfo>>();
                }

                // Log error response
                var errorContent = await response.Content.ReadAsStringAsync();
                Console.WriteLine($"Failed to fetch managers. Response Content: {errorContent}");
                throw new Exception($"Failed to fetch managers. Status Code: {response.StatusCode}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An unexpected exception occurred: {ex.Message}");
                Console.WriteLine($"Stack Trace: {ex.StackTrace}");
                throw;
            }
        }
        public async Task<IEnumerable<Customer>> GetAllCustomersAsync(int userId)
        {
            if (userId <= 0)
            {
                throw new ArgumentException("Invalid UserId", nameof(userId));
            }

            // Construct the API URL with UserId in the query string
            var url = $"https://localhost:7277/api/Manager/customers?userId={userId}";
            Console.WriteLine($"Constructed URL: {url}");

            try
            {
                // Send GET request to backend
                Console.WriteLine("Sending request to fetch all customers...");
                var response = await _httpClient.GetAsync(url);

                Console.WriteLine($"HTTP Response Status Code: {response.StatusCode}");
                if (response.IsSuccessStatusCode)
                {
                    Console.WriteLine("Successfully fetched customers from backend.");
                    return await response.Content.ReadFromJsonAsync<IEnumerable<Customer>>();
                }

                // Log error response
                var errorContent = await response.Content.ReadAsStringAsync();
                Console.WriteLine($"Failed to fetch customers. Response Content: {errorContent}");
                throw new Exception($"Failed to fetch customers. Status Code: {response.StatusCode}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An unexpected exception occurred: {ex.Message}");
                Console.WriteLine($"Stack Trace: {ex.StackTrace}");
                throw;
            }
        }
        public async Task<IEnumerable<Customer>> GetPendingApprovalsAsync(int userId)
        {
            if (userId <= 0)
            {
                throw new ArgumentException("Invalid UserId", nameof(userId));
            }

            // Construct API URL with UserId in query string
            var url = $"https://localhost:7277/api/Manager/pending-approvals?userId={userId}";
            Console.WriteLine($"Constructed URL: {url}");

            try
            {
                Console.WriteLine("Sending request to fetch pending approvals...");
                var response = await _httpClient.GetAsync(url);

                Console.WriteLine($"HTTP Response Status Code: {response.StatusCode}");
                if (response.IsSuccessStatusCode)
                {
                    Console.WriteLine("Successfully fetched pending approvals.");
                    return await response.Content.ReadFromJsonAsync<IEnumerable<Customer>>();
                }

                // Log error response
                var errorContent = await response.Content.ReadAsStringAsync();
                Console.WriteLine($"Failed to fetch pending approvals. Response Content: {errorContent}");
                throw new Exception($"Failed to fetch pending approvals. Status Code: {response.StatusCode}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Unexpected exception occurred: {ex.Message}");
                Console.WriteLine($"Stack Trace: {ex.StackTrace}");
                throw;
            }
        }

        // Approve a customer request
        public async Task<bool> ApproveCustomerRequestAsync(int cusId)
        {
            if (cusId <= 0)
            {
                throw new ArgumentException("Invalid Customer ID", nameof(cusId));
            }

            // Construct API URL with cusId
            var url = $"https://localhost:7277/api/Manager/approve-request/{cusId}";
            Console.WriteLine($"Constructed URL for approving request: {url}");

            try
            {
                Console.WriteLine($"Sending request to approve customer ID: {cusId}...");
                var response = await _httpClient.PostAsync(url, null); // POST request with no body

                Console.WriteLine($"HTTP Response Status Code: {response.StatusCode}");
                if (response.IsSuccessStatusCode)
                {
                    Console.WriteLine($"Successfully approved customer ID: {cusId}");
                    return true;
                }

                // Log error response
                var errorContent = await response.Content.ReadAsStringAsync();
                Console.WriteLine($"Error approving customer ID: {cusId}. Response Content: {errorContent}");
                return false;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception occurred while approving customer ID {cusId}: {ex.Message}");
                Console.WriteLine($"Stack Trace: {ex.StackTrace}");
                throw;
            }
        }

        // Reject a customer request
        public async Task<bool> RejectCustomerRequestAsync(int cusId)
        {
            if (cusId <= 0)
            {
                throw new ArgumentException("Invalid Customer ID", nameof(cusId));
            }

            // Construct API URL with cusId
            var url = $"https://localhost:7277/api/Manager/reject-request/{cusId}";
            Console.WriteLine($"Constructed URL for rejecting request: {url}");

            try
            {
                Console.WriteLine($"Sending request to reject customer ID: {cusId}...");
                var response = await _httpClient.PostAsync(url, null); // POST request with no body

                Console.WriteLine($"HTTP Response Status Code: {response.StatusCode}");
                if (response.IsSuccessStatusCode)
                {
                    Console.WriteLine($"Successfully rejected customer ID: {cusId}");
                    return true;
                }

                // Log error response
                var errorContent = await response.Content.ReadAsStringAsync();
                Console.WriteLine($"Error rejecting customer ID: {cusId}. Response Content: {errorContent}");
                return false;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception occurred while rejecting customer ID {cusId}: {ex.Message}");
                Console.WriteLine($"Stack Trace: {ex.StackTrace}");
                throw;
            }
        }
        
    }
}
