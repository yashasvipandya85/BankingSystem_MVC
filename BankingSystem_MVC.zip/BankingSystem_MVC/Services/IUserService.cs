﻿using BankingSystem_MVC.Models;
namespace BankingSystem_MVC.Services
{
    public interface IUserService
    {
        Task<bool> RegisterUserAsync(UserRegisterViewModel model);
        Task<string> LoginUserAsync(UserLoginViewModel model);
        Task<bool> ForgotPasswordAsync(ForgotPassword model);
        Task<bool> ResetPasswordAsync(ResetPassword model);
        Task<UserProfile> ViewProfileAsync(int userId);
    }
}
