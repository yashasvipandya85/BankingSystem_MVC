using BankingSystem_MVC.Repository;
using BankingSystem_MVC.Services;
using System.Net;
namespace BankingSystem_MVC
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);
            builder.Services.AddDistributedMemoryCache();
            builder.Services.AddHttpContextAccessor();
            builder.Services.AddSession(options =>
            {
                options.IdleTimeout = TimeSpan.FromMinutes(30); 
                options.Cookie.HttpOnly = true;               
                options.Cookie.IsEssential = true;            
            });
            // Add services to the container.
            builder.Services.AddControllersWithViews();
            builder.Services.AddHttpClient<IUserService, UserRepository>(client =>
            {
                client.BaseAddress = new Uri("https://localhost:7277/api/User");
            });

            builder.Services.AddScoped<ICustomerService, CustomerRepository>();
            builder.Services.AddScoped<IAccountService, AccountRepository>();
            builder.Services.AddScoped<IManagerService, ManagerRepository>();
            var app = builder.Build();
           
            // Configure the HTTP request pipeline.
            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Home/Error");
            }
            app.UseStaticFiles();

            app.UseRouting();
            
            app.UseAuthentication();

            app.UseAuthorization();

            app.UseSession();
            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=User}/{action=Index}/{id?}");

            app.Run();
        }
    }
}
