using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using BankingSystem_MVC.Models;
using BankingSystem_MVC.Services;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Cryptography.X509Certificates;
using System.Diagnostics.Eventing.Reader;
using System.Security.Claims;
namespace BankingSystem_MVC.Controllers;

public class UserController : Controller
{
    private readonly IUserService _userService;

    public UserController(IUserService userService)
    {
        _userService = userService;
    }

    public IActionResult Index()
    {
        return View();
    }
    [HttpGet]
    public IActionResult Register()
    {
        return View();
    }

    [HttpPost]
    public async Task<IActionResult> Register(UserRegisterViewModel model)
    {
        if(ModelState.IsValid)
        {
            bool isRegistered = await _userService.RegisterUserAsync(model);
            if(isRegistered)
            {
                TempData["SuccessMessage"] = "Registeration successful! You can now log in";
                return RedirectToAction("Login");
            }
            ModelState.AddModelError("", "Registeration failed. Please try again");
        }
        return View(model);
    }
    [HttpGet]
    public IActionResult Login()
    {
        return View();
    }
    
    [HttpPost]
    public async Task<IActionResult> Login(UserLoginViewModel model)
    {
        if (ModelState.IsValid)
        {
            string token = await _userService.LoginUserAsync(model); 

            if (!string.IsNullOrEmpty(token))
            {
                // Decode the UserId and UserRole from the token
                var userId = DecodeUserIdFromToken(token);
                var userRole = DecodeUserRoleFromToken(token);

                Console.WriteLine($"Decoded UserId: {userId}");
                Console.WriteLine($"Decoded UserRole: {userRole}");

                // Store UserId in session
                HttpContext.Session.SetString("UserId", userId);
                HttpContext.Session.SetString("JwtToken", token);
                Console.WriteLine($"Session started. UserId: {userId}");

                TempData["SuccessMessage"] = "Login successful!";

                if (userRole == "Customer")
                {
                    return RedirectToAction("CustomerDashboard");
                }
                else if (userRole == "Manager")
                {
                    return RedirectToAction("ManagerDashboard");
                }

                ModelState.AddModelError("", "Invalid user role.");
            }
            else
            {
                ModelState.AddModelError("", "Invalid email or password.");
            }
        }

        return View(model);
    }
  
    private string DecodeUserIdFromToken(string token)
    {
        var handler = new JwtSecurityTokenHandler();
        var jwtToken = handler.ReadJwtToken(token);

        // Decode the UserId from the "sub" claim
        var userIdClaim = jwtToken.Claims.FirstOrDefault(c => c.Type == JwtRegisteredClaimNames.Sub);
        if (userIdClaim != null)
        {
            return userIdClaim.Value; // Return the UserId value
        }

        throw new Exception("UserId claim not found in token.");
    }


    private string DecodeUserRoleFromToken(string token)
    {
        try
        {
            var handler = new JwtSecurityTokenHandler();

            if (string.IsNullOrWhiteSpace(token))
            {
                Console.WriteLine("Token is empty or null.");
                return string.Empty;
            }

            if (!handler.CanReadToken(token))
            {
                Console.WriteLine($"Invalid token format: {token}");
                return string.Empty;
            }

            var jwtToken = handler.ReadJwtToken(token);
            var userRoleClaim = jwtToken.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Role);

            if (userRoleClaim != null)
            {
                Console.WriteLine($"Decoded Role: {userRoleClaim.Value}");
                return userRoleClaim.Value; // Return the role (e.g., "Customer" or "Manager")
            }

            Console.WriteLine("Role claim not found in token.");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error decoding token: {ex.Message}");
        }

        return string.Empty;
    }
    
   
    public IActionResult CustomerDashboard()
    {
        ViewData["Title"] = "CustomerDashboard";
        return View();
    }
    public IActionResult ManagerDashboard()
    {
        ViewData["Title"] = "ManagerDashboard";
        return View();
    }
    [HttpGet]
    public IActionResult ForgotPassword()
    {
        return View();
    }

    [HttpGet]
    public IActionResult ResetPassword()
    {
        return View();
    }

    [HttpPost]
    public async Task<IActionResult> ForgotPassword(ForgotPassword model)
    {
        if(ModelState.IsValid)
        {
            bool isUserExists = await _userService.ForgotPasswordAsync(model);
            if(isUserExists)
            {
                TempData["PopupMessage"] = "User Exists.Proceed to Reset Password";
                return RedirectToAction("Login");
            }
            TempData["PopupMessage"] = "Email not found";
        }
        return RedirectToAction("Login");
    }
    [HttpPost]
    public async Task<IActionResult> ResetPassword(ResetPassword model)
    {
        if(ModelState.IsValid)
        {
            if(model.Password != model.ConfirmPassword)
            {
                TempData["PopupMessage"] = "Passwords do not match";
                return RedirectToAction("Login");
            }
            bool isPasswordUpdated = await _userService.ResetPasswordAsync(model);
            if(isPasswordUpdated)
            {
                TempData["PopupMessage"] = "Your password has been updated";
                return RedirectToAction("Login");
            }
            TempData["PopupMessage"] = "Failed to update password.Email not found";
        }
        return RedirectToAction("Login");
    }
    
    [HttpGet]
    public async Task<IActionResult> ViewProfile()
    {
        Console.WriteLine("ViewProfile action invoked.");

        // Get UserId from session as a string
        var userIdString = HttpContext.Session.GetString("UserId");
        Console.WriteLine($"Retrieved UserId from session: {userIdString}");

        // Convert UserId to an integer and validate
        if (!int.TryParse(userIdString, out var userId) || userId == 0)
        {
            Console.WriteLine("Failed to parse UserId or UserId is invalid (UserId = 0).");
            ViewBag.Message = "Invalid UserId. Please log in again.";
            return View("Error");
        }

        Console.WriteLine($"Parsed UserId: {userId}");

        try
        {
            Console.WriteLine($"Attempting to fetch profile for UserId: {userId}");
            var userProfile = await _userService.ViewProfileAsync(userId);

            if (userProfile == null)
            {
                Console.WriteLine($"No profile found for UserId: {userId}");
                ViewBag.Message = "Profile not found.";
                return View("Error");
            }

            Console.WriteLine($"Profile successfully fetched for UserId: {userId}. Redirecting to ViewProfile view.");
            return View(userProfile);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"An exception occurred while fetching the profile for UserId: {userId}. Exception: {ex.Message}");
            Console.WriteLine($"Stack Trace: {ex.StackTrace}");
            ViewBag.Message = $"An error occurred: {ex.Message}";
            return View("Error");
        }
    }

    [HttpGet]
    public IActionResult Menu()
    {
        var userId = HttpContext.Session.GetInt32("UserId");

        if (userId == null || userId == 0)
        {
            ViewBag.Message = "Invalid UserId. Please log in again.";
            return View("Error");
        }

        // Logic for valid UserId
        ViewBag.UserId = userId;
        return View();
    }
    [HttpGet]
    public IActionResult Error(string message = null, string stackTrace = null)
    {
        // Retrieve UserId from session
        var userId = HttpContext.Session.GetInt32("UserId");

        // Pass data to ViewBag
        ViewBag.UserId = userId ?? 0;
        ViewBag.Message = message ?? "An unknown error occurred.";
        ViewBag.StackTrace = stackTrace;

        return View();
    }
    public IActionResult Logout()
    {
        return RedirectToAction("Login", "User"); 
    }

}
