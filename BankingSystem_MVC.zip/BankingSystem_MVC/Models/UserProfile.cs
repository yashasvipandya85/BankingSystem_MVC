﻿namespace BankingSystem_MVC.Models
{
    public class UserProfile
    {
        public int UserId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string UserRole { get; set; }
    }
}
