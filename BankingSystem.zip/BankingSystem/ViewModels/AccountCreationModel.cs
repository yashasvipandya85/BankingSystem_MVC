using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BankingSystem.ViewModels
{
    public class AccountCreationModel
    {
        public string HolderName { get; set; }
        public string AccountNumber { get; set; }
        public int CusId { get; set; }
        public string AccountType { get; set; }
        public string IFSC { get; set; }
        public string BranchName { get; set; }
        public string BranchPhoneNo { get; set; }
         public string BranchEmailId { get; set; }
        public string BranchAddress { get; set; }
    }
}
