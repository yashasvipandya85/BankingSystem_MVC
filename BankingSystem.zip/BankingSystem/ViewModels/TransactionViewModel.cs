namespace BankingSystem.ViewModels
{
    public class TransactionViewModel
{
    public int AccountId { get; set; } 
    public decimal Amount { get; set; } 
    public string TransactionType { get; set; }
}

}