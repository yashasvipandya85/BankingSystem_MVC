﻿using BankingSystem_MVC.Models;
namespace BankingSystem_MVC.Services
{
    public interface IManagerService
    {
        Task<ManagerInfo> CreateManagerAsync(ManagerInfo managerInfo, int userId);
        Task<IEnumerable<ManagerInfo>> GetAllManagersAsync(int userId);
        Task<IEnumerable<Customer>> GetAllCustomersAsync(int userId);
        Task<IEnumerable<Customer>> GetPendingApprovalsAsync(int userId);
        Task<bool> ApproveCustomerRequestAsync(int customerId);
        Task<bool> RejectCustomerRequestAsync(int customerId);
        
    }
}
