﻿using BankingSystem_MVC.Models;
using BankingSystem_MVC.Services;
using Newtonsoft.Json;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;

using System.Text;
using System.Threading.Tasks;
namespace BankingSystem_MVC.Repository
{
    public class CustomerRepository : ICustomerService
    {
        private readonly HttpClient _httpClient;

        public CustomerRepository()
        {
            _httpClient = new HttpClient
            {
                BaseAddress = new Uri("https://localhost:7277") 
            };

            _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        }

        public async Task<bool> CreateCustomerAsync(Customer customer, int userId)
        {
            try
            {
                var jsonData = JsonConvert.SerializeObject(customer);

                var requestUrl = $"/api/Customer/create-customer?userId={userId}";

                var content = new StringContent(jsonData, Encoding.UTF8, "application/json");
                var response = await _httpClient.PostAsync(requestUrl, content);

                Console.WriteLine($"Response Status: {response.StatusCode}");
                var responseBody = await response.Content.ReadAsStringAsync();
                Console.WriteLine($"Response Body: {responseBody}");

                return response.IsSuccessStatusCode;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in CreateCustomerAsync: {ex.Message}");
                return false;
            }
        }
        public async Task<Customer> GetCustomerProfileAsync(int customerId)
        {
            try
            {
                var response = await _httpClient.GetAsync($"/api/Customer/profile/{customerId}");
                Console.WriteLine($"API Call Status: {response.StatusCode}");

                if (response.IsSuccessStatusCode)
                {
                    var jsonData = await response.Content.ReadAsStringAsync();
                    var customer = JsonConvert.DeserializeObject<Customer>(jsonData);
                    Console.WriteLine($"Customer Data: {jsonData}");
                    return customer;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error fetching customer profile: {ex.Message}");
            }

            return null; 
        }
        public async Task<bool> UpdateCustomerAsync(Customer customer)
        {
            try
            {
                var response = await _httpClient.PutAsJsonAsync($"/api/Customer/updateCustomer", customer);
                Console.WriteLine($"HTTP Response Status Code: {response.StatusCode}");

                return response.IsSuccessStatusCode;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception while updating customer: {ex.Message}");
                throw;
            }
        }
        public async Task<Customer> GetCustomerByIdAsync(int customerId)
        {
            if (customerId <= 0)
            {
                throw new ArgumentException("Invalid Customer ID", nameof(customerId));
            }

            try
            {
                // Construct the API endpoint URL
                var response = await _httpClient.GetAsync($"/api/Customer/profile/{customerId}");
                Console.WriteLine($"HTTP Response Status Code: {response.StatusCode}");

                if (response.IsSuccessStatusCode)
                {
                    var jsonData = await response.Content.ReadAsStringAsync();
                    var customer = JsonConvert.DeserializeObject<Customer>(jsonData);
                    Console.WriteLine($"Customer Data: {jsonData}");
                    return customer;
                }
                else
                {
                    Console.WriteLine($"Failed to fetch customer. Status Code: {response.StatusCode}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in GetCustomerByIdAsync: {ex.Message}");
            }

            return null; // Return null if the customer data cannot be fetched
        }

    }
}
