﻿using System.ComponentModel.DataAnnotations.Schema;

namespace BankingSystem_MVC.Models
{
    public class Account
    {
        public int AccountId { get; set; }
        public string HolderName { get; set; }
        public string AccountNumber { get; set; }
        public int CusId { get; set; }
        public string AccountType { get; set; }
        public string IFSC { get; set; }
        public string BranchName { get; set; }
        public string BranchAddress { get; set; }
        public string BranchPhoneNo { get; set; }
        public string BranchEmailId { get; set; }
        public decimal Balance { get; set; }
        public DateTime AccCreationDate { get; set; }
        public int UserId { get; set; }

        [ForeignKey("CusId")]
        public Customer Customer { get; set; }

        [ForeignKey("UserId")]
        public User User { get; set; }
        //public ICollection<Transaction> Transactions { get; set; }
    }
}
