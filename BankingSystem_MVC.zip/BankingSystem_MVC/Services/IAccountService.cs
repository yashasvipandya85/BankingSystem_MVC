﻿using BankingSystem_MVC.Models;

namespace BankingSystem_MVC.Services
{
    public interface IAccountService
    {
        Task<Account> CreateAccountAsync(Account model, int userId);
        Task<bool> DepositAsync(TransactionViewModel model);
        Task<(bool isSuccess, string message)> WithdrawAsync(TransactionViewModel model);
        Task<AccountStatementViewModel> GetAccountStatementAsync(int userId);
        Task<AccountSummaryViewModel> GetAccountSummaryAsync(int userId);
        Task<ShowBalanceViewModel> GetBalanceAsync();
    }
}
