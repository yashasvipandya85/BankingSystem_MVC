using System.Collections.Generic;
using System.Threading.Tasks;
using BankingSystem.Models;
using BankingSystem.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BankingSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ManagerController : ControllerBase
    {
        private readonly IManagerService _managerService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly ILogger<ManagerController> _logger;

        private readonly IUserService _userService;

        public ManagerController(
            IManagerService managerService,
            IHttpContextAccessor httpContextAccessor,
            ILogger<ManagerController> logger,
            IUserService userService
        )
        {
            _managerService = managerService;
            _httpContextAccessor = httpContextAccessor;
            _logger = logger;
            _userService = userService;
        }

        [HttpPost("create")]
        public async Task<IActionResult> CreateManager([FromBody] ManagerCreationModel model)
        {
            if (model == null || !ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var userIdString = HttpContext.Session.GetString("UserId");
            if (string.IsNullOrEmpty(userIdString))
            {
                return Unauthorized("User is not logged in.");
            }
            if (!int.TryParse(userIdString, out int userId))
            {
                _logger.LogError(
                    "Failed to parse UserId from session. SessionId: {SessionId}",
                    HttpContext.Session.Id
                );
                return Unauthorized("Invalid user session data.");
            }
            var newManager = new ManagerInfo
            {
                MobileNo = model.MobileNo,
                City = model.City,
                BranchName = model.BranchName,
                BranchAddress = model.BranchAddress,
                UserId = userId,
            };
            var result = await _managerService.CreateManagerAsync(newManager);
            return Ok(result);
        }

        [HttpGet("all-managers")]
        public async Task<IActionResult> GetAllManagers()
        {
            var managers = await _managerService.GetAllManagersAsync();
            return Ok(managers);
        }

        // [HttpGet("{id}")]
        // public async Task<IActionResult> GetManagerById(int id)
        // {
        //     var manager = await _managerService.GetManagerByIdAsync(id);
        //     if (manager == null)
        //     {
        //         return NotFound("Manager not found.");
        //     }
        //     return Ok(manager);
        // }

        [HttpGet("profile/{userId}")]
        public async Task<IActionResult> ViewProfile(int userId)
        {
            var profile = await _managerService.ViewManagerProfileAsync(userId);
            Console.WriteLine($"Profile retrieved: {profile != null}"); // Log profile retrieval status

            if (profile == null)
            {
                Console.WriteLine("Manager profile not found."); // Log error message
                return NotFound(new { Message = "Manager profile not found." });
            }
            return Ok(profile);
        }
        [HttpGet("customers")]
        [Authorize(Roles = "Manager")] 
        public async Task<IActionResult> GetAllCustomers()
        {
            var customers = await _managerService.GetAllCustomersAsync();
            return Ok(customers);
        }

        [HttpGet("pending-approvals")]
        [Authorize(Roles = "Manager")]
        public async Task<IActionResult> GetPendingApprovals()
        {
            var pendingApprovals = await _managerService.GetPendingApprovalsAsync();
            return Ok(pendingApprovals);
        }

        [HttpPost("approve-request/{cusId}")]
        public async Task<IActionResult> ApproveCustomerRequest(int cusId)
        {
            var customer = await _managerService.ApproveCustomerRequestAsync(cusId);
            if (customer == null)
            {
                return NotFound("Customer request not found or already processed.");
            }
            return Ok(customer);
        }

        [HttpPost("reject-request/{cusId}")]
        public async Task<IActionResult> RejectCustomerRequest(int cusId)
        {
            var customer = await _managerService.RejectCustomerRequestAsync(cusId);
            if (customer == null)
            {
                return NotFound("Customer request not found or already processed.");
            }
            return Ok(customer);
        }


        [HttpPost("unlock/{userId}")]
        public async Task<IActionResult> UnlockUserAccount(int userId)
        {
            var accountStatus = await _userService.GetUserAccountStatusByUserIdAsync(userId);
            if (accountStatus == null)
            {
                return NotFound("User not found.");
            }

            accountStatus.IsLocked = false;
            accountStatus.FailedLoginAttempts = 0;
            await _userService.UpdateUserAccountStatusAsync(accountStatus);

            return Ok("User account has been unlocked.");
        }
       

        // [HttpGet("locked-customers")] 
        // public async Task<IActionResult> GetLockedCustomers() 
        // { 
        //     var lockedCustomers = await _managerService.GetLockedCustomersAsync(); 
        //     return Ok(lockedCustomers);
        // }
    }
}
