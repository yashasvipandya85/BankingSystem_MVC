﻿namespace BankingSystem_MVC.Models
{
    public class ShowBalanceViewModel
    {
        public int AccountId { get; set; }          
        public string HolderName { get; set; }      
        public string AccountNumber { get; set; }   
        public decimal Balance { get; set; }
    }
}
