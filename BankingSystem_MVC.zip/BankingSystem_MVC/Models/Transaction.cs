﻿using System.ComponentModel.DataAnnotations.Schema;

namespace BankingSystem_MVC.Models
{
    public class Transaction
    {
        public int TransactionId { get; set; }
        public int AccountId { get; set; }
        public decimal Amount { get; set; }
        public DateTime TransactionDate { get; set; }
        public string TransactionType { get; set; }
        [ForeignKey("AccountId")]
        public Account Account { get; set; }
    }
}
