﻿using Microsoft.AspNetCore.Mvc;
using BankingSystem_MVC.Models;
using BankingSystem_MVC.Services;
using Newtonsoft.Json;
using System.Net.Http;
namespace BankingSystem_MVC.Controllers
{
    public class ManagerController : Controller
    {
        private readonly IManagerService _managerService;

        public ManagerController(IManagerService managerService)
        {
            _managerService = managerService;
        }

        [HttpGet]
        public IActionResult Create()
        {
            // Return the empty form for manager creation
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(ManagerCreation model)
        {
            Console.WriteLine("Entering Create action in ManagerController.");

            // Step 1: Validate the view model
            if (!ModelState.IsValid)
            {
                Console.WriteLine("Model validation failed.");
                foreach (var error in ModelState.Values.SelectMany(v => v.Errors))
                {
                    Console.WriteLine($" - {error.ErrorMessage}");
                }
                return View(model); // Redisplay the form with validation errors
            }
            Console.WriteLine("Model validation passed.");

            // Step 2: Retrieve UserId from session
            Console.WriteLine("Attempting to retrieve UserId from session.");
            var userIdString = HttpContext.Session.GetString("UserId");
            if (string.IsNullOrEmpty(userIdString))
            {
                Console.WriteLine("No UserId found in session. User is not logged in.");
                ModelState.AddModelError("", "User is not logged in.");
                return View(model);
            }
            Console.WriteLine($"Retrieved UserId from session: {userIdString}");

            // Step 3: Parse UserId
            if (!int.TryParse(userIdString, out int userId))
            {
                Console.WriteLine($"Failed to parse UserId from session: {userIdString}");
                ModelState.AddModelError("", "Invalid user session data.");
                return View(model);
            }
            Console.WriteLine($"Successfully parsed UserId: {userId}");

            // Step 4: Map ManagerCreation to ManagerInfo
            Console.WriteLine("Mapping ManagerCreation to ManagerInfo.");
            var managerInfo = new ManagerInfo
            {
                MobileNo = model.MobileNo,
                City = model.City,
                BranchName = model.BranchName,
                BranchAddress = model.BranchAddress,
                UserId = userId // Associate the logged-in user
            };
            Console.WriteLine("Mapped ManagerCreation to ManagerInfo successfully.");

            // Step 5: Call the service layer
            try
            {
                Console.WriteLine($"Calling service layer with UserId: {userId} via Query String.");
                var result = await _managerService.CreateManagerAsync(managerInfo, userId);

                if (result != null && result.Id > 0)
                {
                    Console.WriteLine($"Manager created successfully. Manager ID: {result.Id}");
                    TempData["SuccessMessage"] = "Manager created successfully!";
                    return RedirectToAction("Create"); // Redirect to clear the form
                }

                Console.WriteLine("Service layer returned null. Manager creation failed.");
                ModelState.AddModelError("", "Failed to create manager. Please try again.");
                return View(model);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Unexpected error occurred: {ex.Message}");
                Console.WriteLine($"Stack Trace: {ex.StackTrace}");
                ModelState.AddModelError("", "An unexpected error occurred. Please try again later.");
                return View(model);
            }
        }
        [HttpGet]
        public async Task<IActionResult> GetAllManagers()
        {
            Console.WriteLine("Entering GetAllManagers action in ManagerController.");

            // Step 1: Retrieve UserId from session
            Console.WriteLine("Attempting to retrieve UserId from session.");
            var userIdString = HttpContext.Session.GetString("UserId");
            if (string.IsNullOrEmpty(userIdString))
            {
                Console.WriteLine("No UserId found in session. User is not logged in.");
                TempData["ErrorMessage"] = "User is not logged in.";
                return RedirectToAction("Login"); // Redirect to login page if not logged in
            }
            Console.WriteLine($"Retrieved UserId from session: {userIdString}");

            // Step 2: Parse UserId
            if (!int.TryParse(userIdString, out int userId))
            {
                Console.WriteLine($"Failed to parse UserId from session: {userIdString}");
                TempData["ErrorMessage"] = "Invalid user session data.";
                return RedirectToAction("Login"); // Redirect to login page if UserId is invalid
            }
            Console.WriteLine($"Successfully parsed UserId: {userId}");

            // Step 3: Call service layer to fetch all managers
            try
            {
                Console.WriteLine($"Calling service layer to fetch all managers for UserId: {userId}.");
                var managers = await _managerService.GetAllManagersAsync(userId);

                Console.WriteLine($"Fetched {managers.Count()} managers successfully.");
                return View(managers); // Pass the list of managers to the view for display
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Unexpected error occurred while fetching managers: {ex.Message}");
                Console.WriteLine($"Stack Trace: {ex.StackTrace}");
                TempData["ErrorMessage"] = "An error occurred while fetching managers. Please try again later.";
                return RedirectToAction("Error"); // Redirect to an error page
            }
        }
        [HttpGet]
        public async Task<IActionResult> GetAllCustomers()
        {
            Console.WriteLine("Entering GetAllCustomers action in CustomerController.");

            // Step 1: Retrieve UserId from session
            Console.WriteLine("Attempting to retrieve UserId from session.");
            var userIdString = HttpContext.Session.GetString("UserId");

            if (string.IsNullOrEmpty(userIdString))
            {
                Console.WriteLine("No UserId found in session. User is not logged in.");
                TempData["ErrorMessage"] = "User is not logged in.";
                return RedirectToAction("Login"); // Redirect to login page if not logged in
            }
            Console.WriteLine($"Retrieved UserId from session: {userIdString}");

            // Step 2: Parse UserId
            if (!int.TryParse(userIdString, out int userId))
            {
                Console.WriteLine($"Failed to parse UserId from session: {userIdString}");
                TempData["ErrorMessage"] = "Invalid user session data.";
                return RedirectToAction("Login"); // Redirect if UserId is invalid
            }
            Console.WriteLine($"Successfully parsed UserId: {userId}");

            // Step 3: Call service layer to fetch all customers
            try
            {
                Console.WriteLine($"Calling service layer to fetch all customers for UserId: {userId}.");
                var customers = await _managerService.GetAllCustomersAsync(userId);

                Console.WriteLine($"Fetched {customers.Count()} customers successfully.");
                return View(customers); // Pass the list of customers to the view for display
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Unexpected error occurred while fetching customers: {ex.Message}");
                Console.WriteLine($"Stack Trace: {ex.StackTrace}");
                TempData["ErrorMessage"] = "An error occurred while fetching customers. Please try again later.";
                return RedirectToAction("Error"); // Redirect to an error page
            }
        }
        [HttpGet]
        public async Task<IActionResult> PendingApprovals()
        {
            Console.WriteLine("Entering PendingApprovals action in ManagerController.");

            // Step 1: Retrieve UserId from session
            var userIdString = HttpContext.Session.GetString("UserId");

            if (string.IsNullOrEmpty(userIdString))
            {
                Console.WriteLine("User is not logged in. UserId not found in session.");
                TempData["ErrorMessage"] = "User is not logged in.";
                return RedirectToAction("Login"); // Redirect to login if not logged in
            }

            if (!int.TryParse(userIdString, out int userId))
            {
                Console.WriteLine("Failed to parse UserId from session.");
                TempData["ErrorMessage"] = "Invalid UserId in session.";
                return RedirectToAction("Login");
            }

            Console.WriteLine($"Retrieved UserId from session: {userId}");

            // Step 2: Fetch pending approvals
            try
            {
                Console.WriteLine("Fetching pending approvals...");
                var pendingApprovals = await _managerService.GetPendingApprovalsAsync(userId);

                if (pendingApprovals == null || !pendingApprovals.Any())
                {
                    Console.WriteLine("No pending approvals found.");
                    TempData["InfoMessage"] = "There are no pending approvals.";
                }

                return View(pendingApprovals);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Unexpected error while fetching pending approvals: {ex.Message}");
                TempData["ErrorMessage"] = "An error occurred while fetching pending approvals.";
                return RedirectToAction("Error");
            }
        }

        [HttpPost]
        public async Task<IActionResult> ApproveRequest(int cusId)
        {
            try
            {
                Console.WriteLine($"Approving request for Customer ID: {cusId}");
                var success = await _managerService.ApproveCustomerRequestAsync(cusId);

                if (!success)
                {
                    Console.WriteLine("Customer request not found or already processed.");
                    TempData["ErrorMessage"] = "Customer request could not be approved. It may already be processed.";
                }
                else
                {
                    TempData["SuccessMessage"] = "Customer request approved successfully!";
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Unexpected error while approving request: {ex.Message}");
                TempData["ErrorMessage"] = "An error occurred while approving the customer request.";
            }

            return RedirectToAction("PendingApprovals"); // Reload the pending approvals list
        }

        [HttpPost]
        public async Task<IActionResult> RejectRequest(int cusId)
        {
            try
            {
                Console.WriteLine($"Rejecting request for Customer ID: {cusId}");
                var success = await _managerService.RejectCustomerRequestAsync(cusId);

                if (!success)
                {
                    Console.WriteLine("Customer request not found or already processed.");
                    TempData["ErrorMessage"] = "Customer request could not be rejected. It may already be processed.";
                }
                else
                {
                    TempData["SuccessMessage"] = "Customer request rejected successfully!";
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Unexpected error while rejecting request: {ex.Message}");
                TempData["ErrorMessage"] = "An error occurred while rejecting the customer request.";
            }

            return RedirectToAction("PendingApprovals"); // Reload the pending approvals list
        }
       
    }
}
