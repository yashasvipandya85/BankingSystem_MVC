﻿namespace BankingSystem_MVC.Models
{
    public class AccountSummaryViewModel
    {
        public int CusId { get; set; }
        public string HolderName { get; set; }
        public string BranchName { get; set; }
        public string AccountNumber { get; set; }
        public decimal Balance { get; set; }
    }
}
