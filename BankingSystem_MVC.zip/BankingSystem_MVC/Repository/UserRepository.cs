﻿using System.Net.Http;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using BankingSystem_MVC.Models;
using BankingSystem_MVC.Services;
using Newtonsoft.Json;
namespace BankingSystem_MVC.Repository
{
    public class UserRepository : IUserService
    {
        private readonly HttpClient _httpClient;

        public UserRepository(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<bool> RegisterUserAsync(UserRegisterViewModel model)
        {
            try
            {
                var jsonData = JsonConvert.SerializeObject(model);
                var content = new StringContent(jsonData, Encoding.UTF8, "application/json");

                var response = await _httpClient.PostAsync("https://localhost:7277/api/User/register", content);
                return response.IsSuccessStatusCode;
            }
            catch(Exception ex)
            {
                Console.WriteLine($"Error during user registeration: {ex.Message}");
                return false;
            }
        }
       
        public async Task<string> LoginUserAsync(UserLoginViewModel model)
        {
            try
            {
                var jsonData = JsonConvert.SerializeObject(model);
                var content = new StringContent(jsonData, Encoding.UTF8, "application/json");

                var response = await _httpClient.PostAsync("https://localhost:7277/api/User/login", content);

                if (response.IsSuccessStatusCode)
                {
                    var result = await response.Content.ReadAsStringAsync();
                    Console.WriteLine($"Token Response: {result}");

                    // Parse the JSON to extract the "token"
                    var responseObject = JsonConvert.DeserializeObject<dynamic>(result);
                    string token = responseObject?.token;

                    if (!string.IsNullOrEmpty(token))
                    {
                        Console.WriteLine($"Extracted Token: {token}");
                        return token;
                    }

                    Console.WriteLine("Token not found in response.");
                }

                return null;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error during login: {ex.Message}");
                return null;
            }
        }

        public async Task<bool> ForgotPasswordAsync(ForgotPassword model)
        {
            try
            {
                var jsonData = JsonConvert.SerializeObject(model);
                var content = new StringContent(jsonData, Encoding.UTF8, "application/json");
                var response = await _httpClient.PostAsync("https://localhost:7277/api/User/forgot-password", content);
                return response.IsSuccessStatusCode;
            }
            catch(Exception ex)
            {
                Console.WriteLine($"Error during Forgot Password : {ex.Message}");
                return false;
            }
        }
        public async Task<bool> ResetPasswordAsync(ResetPassword model)
        {
            try
            {
                var jsonData = JsonConvert.SerializeObject(model);
                var content = new StringContent(jsonData, Encoding.UTF8, "application/json");
                var response = await _httpClient.PostAsync("https://localhost:7277/api/User/reset-password", content);
                return response.IsSuccessStatusCode;
            }
            catch(Exception ex)
            {
                Console.WriteLine($"Error during Reset Password: {ex.Message}");
                return false;
            }
        }
        public async Task<UserProfile> ViewProfileAsync(int userId)
        {
            try
            {
                // Dynamically embed userId into the URL
                var response = await _httpClient.GetAsync($"https://localhost:7277/api/User/viewprofile/{userId}");

                if (response.IsSuccessStatusCode)
                {
                    var jsonData = await response.Content.ReadAsStringAsync();

                    // Deserialize the JSON response into UserProfile ViewModel
                    var userProfile = JsonConvert.DeserializeObject<UserProfile>(jsonData);
                    return userProfile;
                }

                Console.WriteLine($"API Response Status: {response.StatusCode}");
                return null; // Return null if the request was not successful
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in ViewProfileAsync: {ex.Message}");
                return null; // Handle exceptions gracefully
            }
        }

    }
}
