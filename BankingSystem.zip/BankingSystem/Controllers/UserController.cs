using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Azure;
using BankingSystem.Models;
using BankingSystem.Services;
using BankingSystem.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using Microsoft.AspNetCore.JsonPatch;
namespace BankingSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserService _userService;
        private IConfiguration config;

        public UserController(IUserService userService, IConfiguration _config)
        {
            config = _config;
            _userService = userService;
        }

        
           [HttpPost("register")]
public async Task<IActionResult> Register([FromBody] UserRegistrationModel registrationModel)
{
    if (registrationModel == null)
    {
        return BadRequest("User data is required.");
    }

    if (!ModelState.IsValid)
    {
        return BadRequest(ModelState);
    }

    try
    {
        if (await _userService.UserExistsAsync(registrationModel.Email))
        {
            return Conflict("User with this email already exists.");
        }

        var newUser = new User
        {
            Name = registrationModel.Name,
            Email = registrationModel.Email,
            Password = registrationModel.Password,
            ConfirmPassword = registrationModel.ConfirmPassword,  
            UserRole = registrationModel.UserRole
        };

        var registeredUser = await _userService.UserRegisterAsync(newUser);

        // Return response without sensitive data like Password and ConfirmPassword
        return CreatedAtAction(nameof(Register), new { userId = registeredUser.UserId }, new
        {
            registeredUser.UserId,
            registeredUser.Name,
            registeredUser.Email,
            registeredUser.UserRole
        });
    }
    catch (JsonException jsonEx)
    {
        // Log JSON exception
        Console.WriteLine($"JSON Exception: {jsonEx.Message}");
        return StatusCode(500, "There was a problem with the JSON data. Please check your input.");
    }
    catch (Exception ex)
    {
        // Log generic exception
        Console.WriteLine($"Error during registration: {ex.Message}");
        return StatusCode(500, "An error occurred during registration. Please try again later.");
    }
}


        [HttpPost]
        [Route("login")]
        public async Task<IActionResult> Login([FromBody] UserLoginModel model)
        {
            if (model == null)
            {
                Console.WriteLine("Model is null.");
                return BadRequest("User data is required.");
            }
            if (string.IsNullOrWhiteSpace(model.Email))
            {
                Console.WriteLine("Email is empty.");
                return BadRequest("Email is required.");
            }
            if (string.IsNullOrWhiteSpace(model.Password))
            {
                Console.WriteLine("Password is empty.");
                return BadRequest("Password is required.");
            }

            var user = await _userService.UserLoginAsync(model.Email, model.Password);
            if (user != null)
            {
                HttpContext.Session.SetString("UserId", user.UserId.ToString());
                HttpContext.Session.SetString("LastLogin", DateTime.UtcNow.ToString("o"));
                var token = GenerateToken(user);
                Console.WriteLine("User logged in successfully.");
                return Ok(
                    new
                    {
                        UserId = user.UserId,
                        Name = user.Name,
                        Email = user.Email,
                        Password = user.Password,
                        ConfirmPassword = user.ConfirmPassword,
                        UserRole = user.UserRole,
                        OTP = user.OTP,
                        Token = token,
                    }
                );
            }
            else
            {
                var userCheck = await _userService.GetUserByEmailAsync(model.Email);
                if (userCheck != null)
                {
                    Console.WriteLine($"User with email {model.Email} exists.");
                    var accountStatus = await _userService.GetUserAccountStatusByUserIdAsync(userCheck.UserId);
                    if (accountStatus != null)
                    {
                        Console.WriteLine($"Account status retrieved for user ID {userCheck.UserId}. Failed attempts: {accountStatus.FailedLoginAttempts}");
                        if (accountStatus.IsLocked)
                        {
                            Console.WriteLine("Account is locked.");
                            return Unauthorized("Your account has been locked. Consult the manager.");
                        }

                        accountStatus.FailedLoginAttempts++;
                        if (accountStatus.FailedLoginAttempts >= 3)
                        {
                            accountStatus.IsLocked = true;
                            await _userService.UpdateUserAccountStatusAsync(accountStatus);
                            Console.WriteLine($"Account for user ID {userCheck.UserId} is now locked.");
                            return Unauthorized("Your account has been locked. Consult the manager."); // Ensure this message is shown after locking the account
                        }
                        else
                        {
                            await _userService.UpdateUserAccountStatusAsync(accountStatus);
                            Console.WriteLine($"Failed login attempts updated to {accountStatus.FailedLoginAttempts} for user ID {userCheck.UserId}.");
                        }
                    }
                    else
                    {
                        Console.WriteLine($"Account status is null for user ID {userCheck.UserId}."); // Added log statement
                    }
                }
                Console.WriteLine("Invalid email or password.");
                return Unauthorized("Invalid email or password.");
            }
        }

       
        [HttpPut("{userId}")]
        public async Task<IActionResult> UpdateProfile(int userId, [FromBody] UpdateProfileModel updateModel)
        {
            if (updateModel == null)
            {
                return BadRequest("User data is required.");
            }

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var updatedUser = new User
                {
                    Name = updateModel.Name,
                    Email = updateModel.Email,
                    Password = updateModel.Password,
                    ConfirmPassword = updateModel.ConfirmPassword,
                    UserRole = updateModel.UserRole,
                    //OTP = updateModel.OTP
                };

                var user = await _userService.UpdateProfileAsync(userId, updatedUser);
                return Ok(user);
            }
            catch (InvalidOperationException ex)
            {
                return NotFound(ex.Message);
            }
        }


        [HttpGet("exists/{email}")]
        public async Task<IActionResult> UserExists(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
            {
                return BadRequest("Email is required.");
            }

            var exists = await _userService.UserExistsAsync(email);
            return Ok(new { Exists = exists });
        }

        [HttpGet("viewprofile/{userId}")]
        public async Task<IActionResult> ViewProfile(int userId)
        {
            var result = await _userService.ViewProfileAsync(userId);
            return result == null ? NotFound("Profile not found.") : Ok(result);
        }

        [HttpPost("forgot-password")]
        public async Task<IActionResult> ForgotPassword([FromBody] ForgotPasswordRequest model)
        {
            if (string.IsNullOrWhiteSpace(model.Email))
            {
                return BadRequest(new { message = "Email is required." });
            }

            var user = await _userService.GetUserByEmailAsync(model.Email);
            if (user == null)
            {
                return NotFound(new { message = "Email not found." });
            }

            return Ok(new { message = "Email exists. Proceed to reset password." });
        }

        [HttpPost("reset-password")]
        public async Task<IActionResult> ResetPassword([FromBody] ResetPasswordRequest model)
        {
            if (
                string.IsNullOrWhiteSpace(model.Email)
                || string.IsNullOrWhiteSpace(model.Password)
                || string.IsNullOrWhiteSpace(model.ConfirmPassword)
            )
            {
                return BadRequest(
                    new { message = "Email, new password, and confirm password are required." }
                );
            }

            if (model.Password != model.ConfirmPassword)
            {
                return BadRequest(
                    new { message = "New password and confirm password do not match." }
                );
            }

            var isPasswordUpdated = await _userService.UpdatePasswordAsync(
                model.Email,
                model.Password,
                model.ConfirmPassword
            );
            if (isPasswordUpdated)
            {
                return Ok(new { message = "Password has been updated successfully." });
            }
            else
            {
                return NotFound(new { message = "Email not found." });
            }
        }

        [HttpGet("logout/{userId}")]
        public async Task<IActionResult> LogOutUser(int userId)
        {
            var user = await _userService.LogOutUserAsync(userId);
            if (user == null)
            {
                return NotFound("User not found.");
            }

            HttpContext.Session.Clear();
            return Ok(user);
        }

        [NonAction]
        private string GenerateToken(User user)
        {
            
            var claims = new List<Claim>
            {
                new Claim(JwtRegisteredClaimNames.Sub, user.Name),
                new Claim(JwtRegisteredClaimNames.Email, user.Email),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                new Claim(ClaimTypes.Role, user.UserRole),
            };

            var securityKey = new SymmetricSecurityKey(
                Encoding.UTF8.GetBytes(config.GetValue<string>("Jwt:secret"))
            );
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);
            var token = new JwtSecurityToken(
                issuer: config.GetValue<string>("Jwt:issuer"),
                audience: config.GetValue<string>("Jwt:audience"),
                claims: claims,
                expires: DateTime.Now.AddMinutes(30),
                signingCredentials: credentials
            );
            string tokenString = new JwtSecurityTokenHandler().WriteToken(token);
            return tokenString;
        }
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteUser(int id)
        {
            var result = await _userService.DeleteUserAsync(id);
            if(!result)
            {
                return NotFound();
            }
            return Ok();
        }
        
        [HttpPatch("{id}")]
        public async Task<IActionResult> PatchUser(int id, [FromBody] JsonPatchDocument<UpdateProfileModel> patchDocument)
        {
            if (patchDocument == null)
            {
                Console.WriteLine("Patch document is null.");
                return BadRequest("Patch document cannot be null.");
            }

            // Log the incoming patch operations for debugging
            foreach (var operation in patchDocument.Operations)
            {
                Console.WriteLine($"Operation: {operation.op}, Path: {operation.path}, Value: {operation.value}");
            }

            var result = await _userService.PatchUserAsync(id, patchDocument);
            if (!result)
            {
                Console.WriteLine($"User with ID {id} not found."); 
                return NotFound($"User with ID {id} not found.");
            }

            Console.WriteLine("Patch operation applied successfully."); 
            return Ok("User updated successfully.");
        }

    }
}
