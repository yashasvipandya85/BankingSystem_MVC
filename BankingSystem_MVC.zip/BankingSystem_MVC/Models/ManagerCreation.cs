﻿namespace BankingSystem_MVC.Models
{
    public class ManagerCreation 
    { 
        public string MobileNo { get; set; } 
        public string City { get; set; } 
        public string BranchName { get; set; } 
        public string BranchAddress { get; set; } 
    }
}
